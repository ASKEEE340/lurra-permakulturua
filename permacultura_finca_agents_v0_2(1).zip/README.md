# Sistema de agentes — finca de permacultura

Proyecto inicial para recopilar y organizar datos de terreno, agua, clima, suelo, vegetación y parcelas.

Estado: plantilla inicial. Las conexiones a fuentes oficiales y automatizaciones deben configurarse antes de usarlo como sistema automático.
