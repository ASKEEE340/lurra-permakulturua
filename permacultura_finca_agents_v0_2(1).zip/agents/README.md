# Agentes

- maestro: coordina tareas.
- terreno: relieve, MDT/LiDAR, pendientes y orientación.
- agua: hidrografía y escorrentía.
- clima: precipitación, temperatura y viento.
- suelo: cartografía y datos edafológicos.
- vegetacion: cobertura y cambios temporales.
- parcelas: catastro/parcelario y ortofotos.
- analista: cruza resultados y detecta datos faltantes.

Esta versión contiene la estructura; no ejecuta agentes por sí sola.
